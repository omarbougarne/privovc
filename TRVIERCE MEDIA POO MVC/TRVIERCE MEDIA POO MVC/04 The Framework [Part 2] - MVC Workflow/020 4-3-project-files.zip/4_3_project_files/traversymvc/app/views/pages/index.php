<h1><?php echo $data['title']; ?></h1>
