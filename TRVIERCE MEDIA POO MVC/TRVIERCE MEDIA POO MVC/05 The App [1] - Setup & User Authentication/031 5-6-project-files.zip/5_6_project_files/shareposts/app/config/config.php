<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASS', '123456');
  define('DB_NAME', 'shareposts');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://localhost/shareposts');
  // Site Name
  define('SITENAME', 'SharePosts');
  // App Version
  define('APPVERSION', '1.0.0');