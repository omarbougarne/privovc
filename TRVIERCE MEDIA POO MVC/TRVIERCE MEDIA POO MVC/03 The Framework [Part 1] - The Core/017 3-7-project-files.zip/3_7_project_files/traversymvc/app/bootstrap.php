<?php
  // Load Libraries
  require_once 'libraries/core.php';
  require_once 'libraries/controller.php';
  require_once 'libraries/database.php';
