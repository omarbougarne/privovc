<?php
  class Pages {
    public function __construct(){
      echo 'Pages loaded';
    }
  }